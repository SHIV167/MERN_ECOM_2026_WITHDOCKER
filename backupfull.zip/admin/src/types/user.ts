export interface User {
  _id: string;
  email: string;
  name?: string;
  isAdmin: boolean;
  createdAt: string;
  updatedAt: string;
}
