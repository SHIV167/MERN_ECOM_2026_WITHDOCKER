declare module 'react-hot-toast';
